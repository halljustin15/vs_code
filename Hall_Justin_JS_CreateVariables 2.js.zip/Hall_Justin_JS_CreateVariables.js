var ridersHeight;
// store the rider's Height
var requiredHeight;
// rider's height must be greater than or equal to 42
var ridersAge;
// store the rider's age
var requiredAge;
// rider's age must be older than the age of 10
if ( ridersHeight >= requiredHeight && ridersAge > requiredAge ) {
    console.log("Get on that ride, kiddo!")
}
else {
    console.log("Sorry kiddo. Maybe Next year!")
}